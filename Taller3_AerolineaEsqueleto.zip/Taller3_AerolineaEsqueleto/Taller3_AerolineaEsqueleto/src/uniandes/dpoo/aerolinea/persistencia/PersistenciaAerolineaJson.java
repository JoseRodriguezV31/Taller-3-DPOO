package uniandes.dpoo.aerolinea.persistencia;

import uniandes.dpoo.aerolinea.modelo.Aerolinea;

public class PersistenciaAerolineaJson implements IPersistenciaAerolinea{
	@Override
    public void cargarAerolinea( String archivo, Aerolinea aerolinea )
    {
        // No está implementado (y no es necesario para el taller)
    }

    @Override
    public void salvarAerolinea( String archivo, Aerolinea aerolinea )
    {
        // No está implementado (y no es necesario para el taller)
    }

}
